public class PedidoPizza extends Pedido implements OperacionesPedido {

    private String tamanio;
    private String[] ingredientesExtras;

    public PedidoPizza(String cliente, String direccion, double precioBase,
                       TipoComida tipo, boolean delivery, String tamanio,
                       String[] ingredientesExtras) {

        super(cliente, direccion, precioBase, tipo, delivery);
        this.tamanio = tamanio;
        this.ingredientesExtras = ingredientesExtras;
    }

    @Override
    public void mostrarDetallesEspeciales() {
        System.out.println("---- DETALLES PIZZA ----");
        System.out.println("Tamaño: " + tamanio);

        System.out.print("Ingredientes extras: ");
        for (String ing : ingredientesExtras) {
            System.out.print(ing + " ");
        }
        System.out.println();
    }

    @Override
    public void mostrarResumenPedido() {
        System.out.println("Cliente: " + getCliente());
        System.out.println("Dirección: " + getDireccion());
        System.out.println("Tipo: " + getTipo());
    }

    @Override
    public double calcularCostoTotal() {
        double costo = getPrecioBase();

        double deliveryCosto = isDelivery() ? 3.50 : 0;

        return costo + deliveryCosto;
    }

    @Override
    public int estimarTiempoEntrega() {
        int tiempo = 25;
        if (isDelivery()) tiempo += 10;
        return tiempo;
    }
}