public class PedidoHamburguesa extends Pedido implements OperacionesPedido {

    private boolean comboCompleto;
    private int nivelPicante;

    public PedidoHamburguesa(String cliente, String direccion, double precioBase,
                             TipoComida tipo, boolean delivery,
                             boolean comboCompleto, int nivelPicante) {

        super(cliente, direccion, precioBase, tipo, delivery);
        this.comboCompleto = comboCompleto;
        this.nivelPicante = nivelPicante;
    }

    @Override
    public void mostrarDetallesEspeciales() {
        System.out.println("---- DETALLES HAMBURGUESA ----");
        System.out.println("Combo completo: " + comboCompleto);
        System.out.println("Nivel de picante: " + nivelPicante);
    }

    @Override
    public void mostrarResumenPedido() {
        System.out.println("Cliente: " + getCliente());
        System.out.println("Dirección: " + getDireccion());
        System.out.println("Tipo: " + getTipo());
    }

    @Override
    public double calcularCostoTotal() {
        double costo = getPrecioBase();
        double deliveryCosto = isDelivery() ? 2.80 : 0;
        return costo + deliveryCosto;
    }

    @Override
    public int estimarTiempoEntrega() {
        int tiempo = 15;
        if (isDelivery()) tiempo += 10;
        return tiempo;
    }
}