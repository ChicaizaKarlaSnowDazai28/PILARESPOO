public interface OperacionesPedido {
    double calcularCostoTotal();
    void mostrarResumenPedido();
    int estimarTiempoEntrega();
}
