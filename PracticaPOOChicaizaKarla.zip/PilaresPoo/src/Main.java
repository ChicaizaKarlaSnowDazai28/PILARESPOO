import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Pedido> pedidos = new ArrayList<>();

        pedidos.add(new PedidoPizza(
                "Ana",
                "Calle 5",
                12.50,
                TipoComida.PIZZA,
                true,
                "Grande",
                new String[]{"Queso extra", "Pepperoni"}
        ));

        pedidos.add(new PedidoHamburguesa(
                "Luis",
                "Av. Central 20",
                8.75,
                TipoComida.HAMBURGUESA,
                false,
                true,
                3
        ));


        for (Pedido p : pedidos) {
            p.mostrarDetallesEspeciales();
            ((OperacionesPedido)p).mostrarResumenPedido();
            System.out.println("Total: $" + ((OperacionesPedido)p).calcularCostoTotal());
            System.out.println("Tiempo: " + ((OperacionesPedido)p).estimarTiempoEntrega() + " min");
            System.out.println("**************************");
        }
    }
}